package com.example.calculator.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

enum class ButtonType {
    NUMBER,
    OPERATOR,
    FUNCTION,
    CLEAR,
    EQUALS
}

@Composable
fun CalculatorButton(
    text: String,
    type: ButtonType,
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 24.sp,
    vibrationEnabled: Boolean = true,
    testTag: String = "btn_$text",
    icon: ImageVector? = null,
    onClick: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val isDark = isSystemInDarkTheme() || MaterialTheme.colorScheme.background == ProCalcDarkBackground

    val (containerColor, contentColor) = when (type) {
        ButtonType.NUMBER -> if (isDark) {
            ProCalcNumberKeyDark to ProCalcNumberKeyTextDark
        } else {
            ProCalcNumberKeyLight to ProCalcNumberKeyTextLight
        }
        ButtonType.OPERATOR -> if (isDark) {
            ProCalcOperatorKeyDark to ProCalcOperatorKeyTextDark
        } else {
            ProCalcOperatorKeyLight to ProCalcOperatorKeyTextLight
        }
        ButtonType.FUNCTION -> if (isDark) {
            ProCalcFunctionKeyDark to ProCalcFunctionKeyTextDark
        } else {
            ProCalcFunctionKeyLight to ProCalcFunctionKeyTextLight
        }
        ButtonType.CLEAR -> if (isDark) {
            ProCalcClearKeyDark to ProCalcClearKeyTextDark
        } else {
            ProCalcClearKeyLight to ProCalcClearKeyTextLight
        }
        ButtonType.EQUALS -> if (isDark) {
            ProCalcEqualsKeyDark to ProCalcEqualsKeyTextDark
        } else {
            ProCalcEqualsKeyLight to ProCalcEqualsKeyTextLight
        }
    }

    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1.0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "btn_press_scale"
    )

    Surface(
        modifier = modifier
            .padding(4.dp)
            .scale(scale)
            .testTag(testTag)
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) {
                if (vibrationEnabled) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                }
                onClick()
            },
        shape = RoundedCornerShape(18.dp),
        color = containerColor,
        shadowElevation = if (isDark) 2.dp else 4.dp
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            if (icon != null) {
                androidx.compose.material3.Icon(
                    imageVector = icon,
                    contentDescription = text,
                    tint = contentColor
                )
            } else {
                Text(
                    text = text,
                    color = contentColor,
                    fontSize = fontSize,
                    fontWeight = when (type) {
                        ButtonType.EQUALS, ButtonType.OPERATOR -> FontWeight.Bold
                        ButtonType.NUMBER -> FontWeight.SemiBold
                        else -> FontWeight.Medium
                    }
                )
            }
        }
    }
}
