package com.example.calculator.ui

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.calculator.data.AppDatabase
import com.example.calculator.data.HistoryItem
import com.example.calculator.data.HistoryRepository
import com.example.calculator.data.SettingsRepository
import com.example.calculator.data.ThemeMode
import com.example.calculator.data.UserSettings
import com.example.calculator.engine.AngleUnit
import com.example.calculator.engine.CalculationResult
import com.example.calculator.engine.CalculatorEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CalculatorUiState(
    val expression: String = "",
    val livePreview: String = "",
    val finalResult: String = "",
    val errorMessage: String? = null,
    val angleUnit: AngleUnit = AngleUnit.DEG,
    val isEvaluated: Boolean = false
)

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val historyRepository: HistoryRepository
    private val settingsRepository: SettingsRepository

    init {
        val database = AppDatabase.getDatabase(application)
        historyRepository = HistoryRepository(database.historyDao())
        settingsRepository = SettingsRepository(application)
    }

    val historyList: StateFlow<List<HistoryItem>> = historyRepository.allHistory
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val userSettings: StateFlow<UserSettings> = settingsRepository.userSettingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = UserSettings()
        )

    private val _uiState = MutableStateFlow(CalculatorUiState())
    val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            userSettings.collect { settings ->
                // Apply default angle unit if user hasn't changed it during the session
                if (_uiState.value.expression.isEmpty()) {
                    _uiState.value = _uiState.value.copy(angleUnit = settings.defaultAngleUnit)
                }
            }
        }
    }

    fun onDigit(digit: String) {
        val current = _uiState.value
        val newExpr = if (current.isEvaluated) {
            digit
        } else {
            current.expression + digit
        }
        updateExpressionAndPreview(newExpr, isEvaluated = false)
    }

    fun onDecimal() {
        val current = _uiState.value
        val expr = if (current.isEvaluated) "0." else {
            if (current.expression.isEmpty() || isLastCharOperator(current.expression)) {
                current.expression + "0."
            } else {
                // Check if current number chunk already contains a dot
                val lastNumberChunk = current.expression.takeLastWhile { it.isDigit() || it == '.' }
                if (lastNumberChunk.contains('.')) {
                    current.expression
                } else {
                    current.expression + "."
                }
            }
        }
        updateExpressionAndPreview(expr, isEvaluated = false)
    }

    fun onOperator(op: String) {
        val current = _uiState.value
        val baseExpr = if (current.isEvaluated && current.finalResult.isNotEmpty() && current.errorMessage == null) {
            current.finalResult
        } else {
            current.expression
        }

        if (baseExpr.isEmpty()) {
            if (op == "-") {
                updateExpressionAndPreview("-", isEvaluated = false)
            }
            return
        }

        val lastChar = baseExpr.last()
        val newExpr = if (lastChar in "+-×÷^") {
            baseExpr.dropLast(1) + op
        } else {
            "$baseExpr$op"
        }
        updateExpressionAndPreview(newExpr, isEvaluated = false)
    }

    fun onToggleSign() {
        val current = _uiState.value
        val expr = if (current.isEvaluated && current.finalResult.isNotEmpty() && current.errorMessage == null) {
            current.finalResult
        } else {
            current.expression
        }

        if (expr.isEmpty()) return

        // Toggle sign on the current number or full expression
        val newExpr = if (expr.startsWith("(-") && expr.endsWith(")")) {
            expr.substring(2, expr.length - 1)
        } else if (expr.startsWith("-")) {
            expr.drop(1)
        } else {
            "(-$expr)"
        }
        updateExpressionAndPreview(newExpr, isEvaluated = false)
    }

    fun onPercent() {
        val current = _uiState.value
        val expr = if (current.isEvaluated && current.finalResult.isNotEmpty() && current.errorMessage == null) {
            current.finalResult
        } else {
            current.expression
        }
        if (expr.isEmpty() || isLastCharOperator(expr)) return

        val newExpr = "$expr%"
        updateExpressionAndPreview(newExpr, isEvaluated = false)
    }

    fun onParenthesis(paren: String) {
        val current = _uiState.value
        val newExpr = if (current.isEvaluated) paren else current.expression + paren
        updateExpressionAndPreview(newExpr, isEvaluated = false)
    }

    fun onScientificFunction(fn: String) {
        val current = _uiState.value
        val prefix = if (current.isEvaluated) "" else current.expression
        val newExpr = when (fn) {
            "x²" -> if (prefix.isNotEmpty() && !isLastCharOperator(prefix)) "$prefix^2" else "$prefix"
            "xʸ" -> if (prefix.isNotEmpty() && !isLastCharOperator(prefix)) "$prefix^" else "$prefix"
            "√" -> "$prefix√("
            "sin⁻¹" -> "$prefix sin⁻¹("
            "cos⁻¹" -> "$prefix cos⁻¹("
            "tan⁻¹" -> "$prefix tan⁻¹("
            else -> "$prefix$fn("
        }
        updateExpressionAndPreview(newExpr, isEvaluated = false)
    }

    fun onConstant(constant: String) {
        val current = _uiState.value
        val newExpr = if (current.isEvaluated) constant else current.expression + constant
        updateExpressionAndPreview(newExpr, isEvaluated = false)
    }

    fun onFactorial() {
        val current = _uiState.value
        val expr = if (current.isEvaluated && current.finalResult.isNotEmpty() && current.errorMessage == null) {
            current.finalResult
        } else {
            current.expression
        }
        if (expr.isNotEmpty() && !isLastCharOperator(expr)) {
            updateExpressionAndPreview("$expr!", isEvaluated = false)
        }
    }

    fun onToggleAngleUnit() {
        val currentUnit = _uiState.value.angleUnit
        val nextUnit = if (currentUnit == AngleUnit.DEG) AngleUnit.RAD else AngleUnit.DEG
        _uiState.value = _uiState.value.copy(angleUnit = nextUnit)
        // Refresh live preview with new angle unit
        val preview = calculatePreview(_uiState.value.expression, nextUnit)
        _uiState.value = _uiState.value.copy(livePreview = preview)
    }

    fun onClear() {
        _uiState.value = CalculatorUiState(angleUnit = _uiState.value.angleUnit)
    }

    fun onBackspace() {
        val current = _uiState.value
        if (current.isEvaluated) {
            onClear()
            return
        }
        if (current.expression.isEmpty()) return

        // If ends with multi-character function like "sin(", "sin⁻¹(", remove whole function token
        val expr = current.expression
        val tokensToRemove = listOf("sin⁻¹(", "cos⁻¹(", "tan⁻¹(", "sin(", "cos(", "tan(", "log(", "ln(", "√(")
        val matchedToken = tokensToRemove.firstOrNull { expr.endsWith(it) }

        val newExpr = if (matchedToken != null) {
            expr.dropLast(matchedToken.length)
        } else {
            expr.dropLast(1)
        }

        updateExpressionAndPreview(newExpr, isEvaluated = false)
    }

    fun onEquals() {
        val current = _uiState.value
        val expr = current.expression.trim()
        if (expr.isEmpty()) return

        when (val result = CalculatorEngine.evaluate(expr, current.angleUnit)) {
            is CalculationResult.Success -> {
                val formatted = result.formattedResult
                _uiState.value = current.copy(
                    finalResult = formatted,
                    livePreview = "",
                    errorMessage = null,
                    isEvaluated = true
                )
                // Save to history database
                viewModelScope.launch {
                    historyRepository.addCalculation(expr, formatted)
                }
            }
            is CalculationResult.Error -> {
                _uiState.value = current.copy(
                    finalResult = "",
                    livePreview = "",
                    errorMessage = result.message,
                    isEvaluated = true
                )
            }
        }
    }

    fun reuseExpression(expression: String) {
        updateExpressionAndPreview(expression, isEvaluated = false)
    }

    fun reuseResult(result: String) {
        updateExpressionAndPreview(result, isEvaluated = false)
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            historyRepository.deleteById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            historyRepository.clearAll()
        }
    }

    fun updateTheme(themeMode: ThemeMode) {
        viewModelScope.launch {
            settingsRepository.updateThemeMode(themeMode)
        }
    }

    fun updateVibration(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateVibration(enabled)
        }
    }

    fun updateDefaultAngleUnit(unit: AngleUnit) {
        viewModelScope.launch {
            settingsRepository.updateAngleUnit(unit)
            _uiState.value = _uiState.value.copy(angleUnit = unit)
        }
    }

    fun copyToClipboard(context: Context, text: String, label: String = "Calculation Result") {
        if (text.isEmpty()) return
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
    }

    fun shareCalculation(context: Context, expression: String, result: String) {
        val shareText = if (expression.isNotEmpty() && result.isNotEmpty()) {
            "$expression = $result"
        } else if (result.isNotEmpty()) {
            result
        } else {
            expression
        }

        if (shareText.isEmpty()) return

        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, shareText)
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "Share Calculation via")
        shareIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(shareIntent)
    }

    private fun updateExpressionAndPreview(newExpr: String, isEvaluated: Boolean) {
        val preview = calculatePreview(newExpr, _uiState.value.angleUnit)
        _uiState.value = _uiState.value.copy(
            expression = newExpr,
            livePreview = preview,
            errorMessage = null,
            isEvaluated = isEvaluated
        )
    }

    private fun calculatePreview(expr: String, angleUnit: AngleUnit): String {
        if (expr.isEmpty() || isLastCharOperator(expr)) return ""
        return when (val res = CalculatorEngine.evaluate(expr, angleUnit)) {
            is CalculationResult.Success -> res.formattedResult
            is CalculationResult.Error -> ""
        }
    }

    private fun isLastCharOperator(expr: String): Boolean {
        if (expr.isEmpty()) return false
        val last = expr.last()
        return last in "+-×÷^("
    }
}
