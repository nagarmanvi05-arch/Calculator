package com.example.calculator.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.calculator.ui.CalculatorViewModel
import com.example.calculator.ui.components.ButtonType
import com.example.calculator.ui.components.CalculatorButton
import com.example.calculator.ui.components.CalculatorDisplay

@Composable
fun StandardCalculatorScreen(
    viewModel: CalculatorViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val userSettings by viewModel.userSettings.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val vibrationEnabled = userSettings.vibrationEnabled

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Display
        CalculatorDisplay(
            expression = uiState.expression,
            livePreview = uiState.livePreview,
            finalResult = uiState.finalResult,
            errorMessage = uiState.errorMessage,
            angleUnit = uiState.angleUnit,
            onAngleToggle = { viewModel.onToggleAngleUnit() },
            onCopy = { result ->
                viewModel.copyToClipboard(context, result)
                Toast.makeText(context, "Result copied to clipboard", Toast.LENGTH_SHORT).show()
            },
            onShare = { expr, res ->
                viewModel.shareCalculation(context, expr, res)
            },
            modifier = Modifier.weight(1f)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Keypad Grid: 5 Rows x 4 Columns
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(2.3f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Row 0: Helper Parentheses row for standard calculator
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.7f),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CalculatorButton(
                    text = "(",
                    type = ButtonType.FUNCTION,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onParenthesis("(") }
                )
                CalculatorButton(
                    text = ")",
                    type = ButtonType.FUNCTION,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onParenthesis(")") }
                )
                CalculatorButton(
                    text = "%",
                    type = ButtonType.FUNCTION,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onPercent() }
                )
                CalculatorButton(
                    text = "AC",
                    type = ButtonType.CLEAR,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onClear() }
                )
            }

            // Row 1: ⌫, +/-, ÷
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CalculatorButton(
                    text = "+/-",
                    type = ButtonType.FUNCTION,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onToggleSign() }
                )
                CalculatorButton(
                    text = "⌫",
                    type = ButtonType.FUNCTION,
                    icon = Icons.AutoMirrored.Filled.Backspace,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onBackspace() }
                )
                CalculatorButton(
                    text = "x²",
                    type = ButtonType.FUNCTION,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onScientificFunction("x²") }
                )
                CalculatorButton(
                    text = "÷",
                    type = ButtonType.OPERATOR,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onOperator("÷") }
                )
            }

            // Row 2: 7, 8, 9, ×
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CalculatorButton(
                    text = "7",
                    type = ButtonType.NUMBER,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("7") }
                )
                CalculatorButton(
                    text = "8",
                    type = ButtonType.NUMBER,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("8") }
                )
                CalculatorButton(
                    text = "9",
                    type = ButtonType.NUMBER,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("9") }
                )
                CalculatorButton(
                    text = "×",
                    type = ButtonType.OPERATOR,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onOperator("×") }
                )
            }

            // Row 3: 4, 5, 6, -
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CalculatorButton(
                    text = "4",
                    type = ButtonType.NUMBER,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("4") }
                )
                CalculatorButton(
                    text = "5",
                    type = ButtonType.NUMBER,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("5") }
                )
                CalculatorButton(
                    text = "6",
                    type = ButtonType.NUMBER,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("6") }
                )
                CalculatorButton(
                    text = "-",
                    type = ButtonType.OPERATOR,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onOperator("-") }
                )
            }

            // Row 4: 1, 2, 3, +
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CalculatorButton(
                    text = "1",
                    type = ButtonType.NUMBER,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("1") }
                )
                CalculatorButton(
                    text = "2",
                    type = ButtonType.NUMBER,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("2") }
                )
                CalculatorButton(
                    text = "3",
                    type = ButtonType.NUMBER,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("3") }
                )
                CalculatorButton(
                    text = "+",
                    type = ButtonType.OPERATOR,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onOperator("+") }
                )
            }

            // Row 5: 0, ., =
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                CalculatorButton(
                    text = "0",
                    type = ButtonType.NUMBER,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(2f),
                    onClick = { viewModel.onDigit("0") }
                )
                CalculatorButton(
                    text = ".",
                    type = ButtonType.NUMBER,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDecimal() }
                )
                CalculatorButton(
                    text = "=",
                    type = ButtonType.EQUALS,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onEquals() }
                )
            }
        }
    }
}
