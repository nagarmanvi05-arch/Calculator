package com.example.calculator.ui.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.calculator.ui.CalculatorViewModel
import com.example.calculator.ui.screens.AboutScreen
import com.example.calculator.ui.screens.HistoryScreen
import com.example.calculator.ui.screens.PrivacyPolicyScreen
import com.example.calculator.ui.screens.ScientificCalculatorScreen
import com.example.calculator.ui.screens.SettingsScreen
import com.example.calculator.ui.screens.StandardCalculatorScreen

sealed class Screen(val route: String, val titleRes: Int, val icon: ImageVector) {
    object Standard : Screen("standard", R.string.screen_standard, Icons.Default.Calculate)
    object Scientific : Screen("scientific", R.string.screen_scientific, Icons.Default.Functions)
    object History : Screen("history", R.string.screen_history, Icons.Default.History)
    object Settings : Screen("settings", R.string.screen_settings, Icons.Default.Settings)
    object About : Screen("about", R.string.screen_about, Icons.Default.Calculate)
    object Privacy : Screen("privacy", R.string.screen_privacy, Icons.Default.Calculate)
}

val bottomNavItems = listOf(
    Screen.Standard,
    Screen.Scientific,
    Screen.History,
    Screen.Settings
)

@Composable
fun ProCalcApp(
    viewModel: CalculatorViewModel,
    modifier: Modifier = Modifier
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val showBottomBar = currentRoute in bottomNavItems.map { it.route }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ) {
                    bottomNavItems.forEach { screen ->
                        val selected = currentRoute == screen.route
                        NavigationBarItem(
                            icon = {
                                Icon(
                                    imageVector = screen.icon,
                                    contentDescription = stringResource(screen.titleRes)
                                )
                            },
                            label = { Text(stringResource(screen.titleRes)) },
                            selected = selected,
                            modifier = Modifier.testTag("nav_item_${screen.route}"),
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Standard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Standard.route) {
                StandardCalculatorScreen(viewModel = viewModel)
            }
            composable(Screen.Scientific.route) {
                ScientificCalculatorScreen(viewModel = viewModel)
            }
            composable(Screen.History.route) {
                HistoryScreen(
                    viewModel = viewModel,
                    onNavigateToCalculator = {
                        navController.navigate(Screen.Standard.route) {
                            popUpTo(Screen.Standard.route) { inclusive = false }
                        }
                    }
                )
            }
            composable(Screen.Settings.route) {
                SettingsScreen(
                    viewModel = viewModel,
                    onNavigateToAbout = { navController.navigate(Screen.About.route) },
                    onNavigateToPrivacy = { navController.navigate(Screen.Privacy.route) }
                )
            }
            composable(Screen.About.route) {
                AboutScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable(Screen.Privacy.route) {
                PrivacyPolicyScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}
