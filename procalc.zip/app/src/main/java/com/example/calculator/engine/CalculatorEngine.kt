package com.example.calculator.engine

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.*

enum class AngleUnit {
    DEG,
    RAD
}

sealed class CalculationResult {
    data class Success(val value: Double, val formattedResult: String) : CalculationResult()
    data class Error(val message: String) : CalculationResult()
}

/**
 * Robust mathematical expression parser and evaluator for ProCalc.
 * Supports:
 * - Basic operators (+, -, ×, ÷, %)
 * - Power (^ or x^y) and squares
 * - Factorial (!)
 * - Scientific functions (sin, cos, tan, asin, acos, atan, log, ln, sqrt)
 * - Constants (π, e)
 * - Parentheses with implicit multiplication (e.g., 2(3) or 2π or 3sin(30))
 * - Degree and Radian modes
 * - Division by zero and domain error protections
 */
object CalculatorEngine {

    private const val MAX_FACTORIAL = 100

    /**
     * Evaluates the given expression string in DEG or RAD angle mode.
     */
    fun evaluate(expression: String, angleUnit: AngleUnit = AngleUnit.DEG): CalculationResult {
        val trimmed = expression.trim()
        if (trimmed.isEmpty()) {
            return CalculationResult.Error("Empty expression")
        }

        return try {
            val tokens = tokenize(trimmed)
            if (tokens.isEmpty()) {
                return CalculationResult.Error("Empty expression")
            }
            val parser = Parser(tokens, angleUnit)
            val result = parser.parse()

            if (result.isNaN()) {
                CalculationResult.Error("Undefined result")
            } else if (result.isInfinite()) {
                CalculationResult.Error(if (result > 0) "Infinity" else "-Infinity")
            } else {
                CalculationResult.Success(result, formatResult(result))
            }
        } catch (e: ArithmeticException) {
            CalculationResult.Error(e.message ?: "Calculation error")
        } catch (e: IllegalArgumentException) {
            CalculationResult.Error(e.message ?: "Invalid input")
        } catch (e: Exception) {
            CalculationResult.Error("Error")
        }
    }

    /**
     * Formats a floating point number cleanly:
     * - Fixes binary floating point inaccuracies (e.g. 0.1 + 0.2 -> 0.3)
     * - Removes unnecessary trailing zeros (.0)
     * - Uses scientific notation for extremely large or tiny numbers
     */
    fun formatResult(value: Double): String {
        if (value.isNaN()) return "Error"
        if (value.isInfinite()) return if (value > 0) "Infinity" else "-Infinity"

        // Handle precision glitches close to 0 (like sin(180 deg) or cos(90 deg))
        val cleanedValue = if (abs(value) < 1e-13) 0.0 else value

        val absVal = abs(cleanedValue)
        return if (absVal != 0.0 && (absVal >= 1e12 || absVal < 1e-6)) {
            // Scientific notation
            val symbols = DecimalFormatSymbols(Locale.US)
            val df = DecimalFormat("0.######E0", symbols)
            df.format(cleanedValue).replace("E", " × 10^")
        } else {
            // Standard decimal formatting
            val bd = BigDecimal.valueOf(cleanedValue)
                .setScale(10, RoundingMode.HALF_UP)
                .stripTrailingZeros()
            bd.toPlainString()
        }
    }

    // Token definitions
    private sealed class Token {
        data class Number(val value: Double) : Token()
        data class Identifier(val name: String) : Token()
        data class Operator(val op: Char) : Token()
        object LeftParen : Token()
        object RightParen : Token()
        object Percent : Token()
        object Factorial : Token()
    }

    private fun tokenize(expr: String): List<Token> {
        val tokens = mutableListOf<Token>()
        var i = 0
        val n = expr.length

        while (i < n) {
            val c = expr[i]
            when {
                c.isWhitespace() -> {
                    i++
                }
                c.isDigit() || c == '.' -> {
                    val start = i
                    var hasDot = (c == '.')
                    i++
                    while (i < n && (expr[i].isDigit() || (!hasDot && expr[i] == '.'))) {
                        if (expr[i] == '.') hasDot = true
                        i++
                    }
                    val numStr = expr.substring(start, i)
                    val value = numStr.toDoubleOrNull() ?: throw IllegalArgumentException("Invalid number: $numStr")
                    tokens.add(Token.Number(value))
                }
                c.isLetter() || c == 'π' || c == '√' -> {
                    val start = i
                    if (c == 'π') {
                        tokens.add(Token.Identifier("π"))
                        i++
                    } else if (c == '√') {
                        tokens.add(Token.Identifier("sqrt"))
                        i++
                    } else {
                        while (i < n && (expr[i].isLetter() || expr[i] == '⁻' || expr[i] == '¹')) {
                            i++
                        }
                        val ident = expr.substring(start, i)
                        tokens.add(Token.Identifier(ident))
                    }
                }
                c == '(' -> {
                    tokens.add(Token.LeftParen)
                    i++
                }
                c == ')' -> {
                    tokens.add(Token.RightParen)
                    i++
                }
                c == '%' -> {
                    tokens.add(Token.Percent)
                    i++
                }
                c == '!' -> {
                    tokens.add(Token.Factorial)
                    i++
                }
                c == '+' || c == '-' || c == '×' || c == '*' || c == '÷' || c == '/' || c == '^' -> {
                    val normOp = when (c) {
                        '*' -> '×'
                        '/' -> '÷'
                        else -> c
                    }
                    tokens.add(Token.Operator(normOp))
                    i++
                }
                else -> {
                    throw IllegalArgumentException("Unexpected character: $c")
                }
            }
        }

        // Insert implicit multiplication tokens where appropriate (e.g. 2(3) -> 2*(3), (2)(3) -> (2)*(3), 2π -> 2*π)
        val withImplicitMul = mutableListOf<Token>()
        for (idx in tokens.indices) {
            val curr = tokens[idx]
            if (idx > 0) {
                val prev = tokens[idx - 1]
                val prevCanEndVal = prev is Token.Number || prev is Token.RightParen || prev is Token.Percent || prev is Token.Factorial ||
                        (prev is Token.Identifier && (prev.name == "π" || prev.name == "e"))
                val currCanStartVal = curr is Token.Number || curr is Token.LeftParen || curr is Token.Identifier

                if (prevCanEndVal && currCanStartVal) {
                    withImplicitMul.add(Token.Operator('×'))
                }
            }
            withImplicitMul.add(curr)
        }

        return withImplicitMul
    }

    private class Parser(
        private val tokens: List<Token>,
        private val angleUnit: AngleUnit
    ) {
        private var pos = 0

        private fun peek(): Token? = if (pos < tokens.size) tokens[pos] else null
        private fun consume(): Token = tokens[pos++]

        fun parse(): Double {
            val result = parseExpression()
            if (pos < tokens.size) {
                throw IllegalArgumentException("Unexpected token after expression")
            }
            return result
        }

        // Expression: Term (('+' | '-') Term)*
        private fun parseExpression(): Double {
            var left = parseTerm()

            while (true) {
                val token = peek()
                if (token is Token.Operator && (token.op == '+' || token.op == '-')) {
                    consume()
                    val right = parseTerm()
                    left = if (token.op == '+') left + right else left - right
                } else {
                    break
                }
            }
            return left
        }

        // Term: Power (('×' | '÷') Power)*
        private fun parseTerm(): Double {
            var left = parsePower()

            while (true) {
                val token = peek()
                if (token is Token.Operator && (token.op == '×' || token.op == '÷')) {
                    consume()
                    val right = parsePower()
                    if (token.op == '÷') {
                        if (abs(right) < 1e-15) {
                            throw ArithmeticException("Cannot divide by zero")
                        }
                        left /= right
                    } else {
                        left *= right
                    }
                } else {
                    break
                }
            }
            return left
        }

        // Power: Factor ('^' Power)? (right associative)
        private fun parsePower(): Double {
            val base = parseFactor()
            val token = peek()
            if (token is Token.Operator && token.op == '^') {
                consume()
                val exponent = parsePower()
                val res = base.pow(exponent)
                if (res.isNaN()) {
                    throw ArithmeticException("Invalid power calculation")
                }
                return res
            }
            return base
        }

        // Factor: PostfixUnary (like %, !) applied to Primary
        private fun parseFactor(): Double {
            // Check for prefix unary operators (+, -)
            val token = peek()
            if (token is Token.Operator && (token.op == '+' || token.op == '-')) {
                consume()
                val operand = parseFactor()
                val res = if (token.op == '-') -operand else operand
                return parsePostfix(res)
            }

            val primary = parsePrimary()
            return parsePostfix(primary)
        }

        private fun parsePostfix(initial: Double): Double {
            var current = initial
            while (true) {
                when (peek()) {
                    is Token.Percent -> {
                        consume()
                        current /= 100.0
                    }
                    is Token.Factorial -> {
                        consume()
                        current = computeFactorial(current)
                    }
                    else -> break
                }
            }
            return current
        }

        private fun computeFactorial(value: Double): Double {
            if (value < 0 || value != floor(value) || value > MAX_FACTORIAL) {
                throw ArithmeticException("Invalid factorial input")
            }
            val intVal = value.toInt()
            if (intVal == 0 || intVal == 1) return 1.0
            var result = 1.0
            for (i in 2..intVal) {
                result *= i
                if (result.isInfinite()) {
                    throw ArithmeticException("Overflow in factorial")
                }
            }
            return result
        }

        // Primary: Number, Constants, Functions, Parentheses
        private fun parsePrimary(): Double {
            val token = peek() ?: throw IllegalArgumentException("Unexpected end of expression")

            return when (token) {
                is Token.Number -> {
                    consume()
                    token.value
                }
                is Token.LeftParen -> {
                    consume()
                    val result = parseExpression()
                    val next = peek()
                    if (next !is Token.RightParen) {
                        throw IllegalArgumentException("Missing closing parenthesis")
                    }
                    consume() // discard ')'
                    result
                }
                is Token.Identifier -> {
                    consume()
                    when (val name = token.name.lowercase()) {
                        "π", "pi" -> Math.PI
                        "e" -> Math.E
                        "sin", "cos", "tan", "asin", "sin⁻¹", "acos", "cos⁻¹", "atan", "tan⁻¹",
                        "log", "ln", "sqrt" -> {
                            val arg = parseArgument()
                            evaluateFunction(name, arg)
                        }
                        else -> throw IllegalArgumentException("Unknown function or constant: ${token.name}")
                    }
                }
                else -> throw IllegalArgumentException("Unexpected token in calculation")
            }
        }

        private fun parseArgument(): Double {
            // Function argument can be in parentheses or next factor
            return if (peek() is Token.LeftParen) {
                consume()
                val arg = parseExpression()
                val close = peek()
                if (close !is Token.RightParen) {
                    throw IllegalArgumentException("Missing closing parenthesis for function")
                }
                consume()
                arg
            } else {
                parseFactor()
            }
        }

        private fun evaluateFunction(name: String, arg: Double): Double {
            return when (name) {
                "sin" -> {
                    val radians = if (angleUnit == AngleUnit.DEG) Math.toRadians(arg) else arg
                    val sinVal = sin(radians)
                    if (abs(sinVal) < 1e-14) 0.0 else sinVal
                }
                "cos" -> {
                    val radians = if (angleUnit == AngleUnit.DEG) Math.toRadians(arg) else arg
                    val cosVal = cos(radians)
                    if (abs(cosVal) < 1e-14) 0.0 else cosVal
                }
                "tan" -> {
                    val radians = if (angleUnit == AngleUnit.DEG) Math.toRadians(arg) else arg
                    val cosVal = cos(radians)
                    if (abs(cosVal) < 1e-14) {
                        throw ArithmeticException("Tangent undefined at 90°")
                    }
                    val tanVal = tan(radians)
                    if (abs(tanVal) < 1e-14) 0.0 else tanVal
                }
                "asin", "sin⁻¹" -> {
                    if (arg < -1.0 || arg > 1.0) {
                        throw ArithmeticException("Domain error: asin requires [-1, 1]")
                    }
                    val rad = asin(arg)
                    if (angleUnit == AngleUnit.DEG) Math.toDegrees(rad) else rad
                }
                "acos", "cos⁻¹" -> {
                    if (arg < -1.0 || arg > 1.0) {
                        throw ArithmeticException("Domain error: acos requires [-1, 1]")
                    }
                    val rad = acos(arg)
                    if (angleUnit == AngleUnit.DEG) Math.toDegrees(rad) else rad
                }
                "atan", "tan⁻¹" -> {
                    val rad = atan(arg)
                    if (angleUnit == AngleUnit.DEG) Math.toDegrees(rad) else rad
                }
                "log" -> {
                    if (arg <= 0) {
                        throw ArithmeticException("Domain error: log requires positive value")
                    }
                    log10(arg)
                }
                "ln" -> {
                    if (arg <= 0) {
                        throw ArithmeticException("Domain error: ln requires positive value")
                    }
                    ln(arg)
                }
                "sqrt" -> {
                    if (arg < 0) {
                        throw ArithmeticException("Domain error: square root of negative number")
                    }
                    sqrt(arg)
                }
                else -> throw IllegalArgumentException("Unknown function: $name")
            }
        }
    }
}
