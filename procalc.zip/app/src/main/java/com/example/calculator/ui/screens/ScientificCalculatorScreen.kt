package com.example.calculator.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.calculator.engine.AngleUnit
import com.example.calculator.ui.CalculatorViewModel
import com.example.calculator.ui.components.ButtonType
import com.example.calculator.ui.components.CalculatorButton
import com.example.calculator.ui.components.CalculatorDisplay

@Composable
fun ScientificCalculatorScreen(
    viewModel: CalculatorViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val userSettings by viewModel.userSettings.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var isInverse by remember { mutableStateOf(false) }
    val vibrationEnabled = userSettings.vibrationEnabled

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Display
        CalculatorDisplay(
            expression = uiState.expression,
            livePreview = uiState.livePreview,
            finalResult = uiState.finalResult,
            errorMessage = uiState.errorMessage,
            angleUnit = uiState.angleUnit,
            onAngleToggle = { viewModel.onToggleAngleUnit() },
            onCopy = { result ->
                viewModel.copyToClipboard(context, result)
                Toast.makeText(context, "Result copied to clipboard", Toast.LENGTH_SHORT).show()
            },
            onShare = { expr, res ->
                viewModel.shareCalculation(context, expr, res)
            },
            modifier = Modifier.weight(0.9f)
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Scientific Keypad: 5 columns
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(2.6f),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            // Row 1: DEG/RAD, sin/sin⁻¹, cos/cos⁻¹, tan/tan⁻¹, π
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                CalculatorButton(
                    text = uiState.angleUnit.name,
                    type = ButtonType.FUNCTION,
                    fontSize = 15.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onToggleAngleUnit() }
                )
                CalculatorButton(
                    text = if (isInverse) "sin⁻¹" else "sin",
                    type = ButtonType.FUNCTION,
                    fontSize = 15.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onScientificFunction(if (isInverse) "sin⁻¹" else "sin") }
                )
                CalculatorButton(
                    text = if (isInverse) "cos⁻¹" else "cos",
                    type = ButtonType.FUNCTION,
                    fontSize = 15.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onScientificFunction(if (isInverse) "cos⁻¹" else "cos") }
                )
                CalculatorButton(
                    text = if (isInverse) "tan⁻¹" else "tan",
                    type = ButtonType.FUNCTION,
                    fontSize = 15.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onScientificFunction(if (isInverse) "tan⁻¹" else "tan") }
                )
                CalculatorButton(
                    text = "π",
                    type = ButtonType.FUNCTION,
                    fontSize = 18.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onConstant("π") }
                )
            }

            // Row 2: INV, ln, log, √, e
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                CalculatorButton(
                    text = if (isInverse) "INV ✓" else "INV",
                    type = ButtonType.FUNCTION,
                    fontSize = 14.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { isInverse = !isInverse }
                )
                CalculatorButton(
                    text = "ln",
                    type = ButtonType.FUNCTION,
                    fontSize = 16.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onScientificFunction("ln") }
                )
                CalculatorButton(
                    text = "log",
                    type = ButtonType.FUNCTION,
                    fontSize = 16.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onScientificFunction("log") }
                )
                CalculatorButton(
                    text = "√",
                    type = ButtonType.FUNCTION,
                    fontSize = 18.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onScientificFunction("√") }
                )
                CalculatorButton(
                    text = "e",
                    type = ButtonType.FUNCTION,
                    fontSize = 18.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onConstant("e") }
                )
            }

            // Row 3: x², xʸ, !, (, )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                CalculatorButton(
                    text = "x²",
                    type = ButtonType.FUNCTION,
                    fontSize = 16.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onScientificFunction("x²") }
                )
                CalculatorButton(
                    text = "xʸ",
                    type = ButtonType.FUNCTION,
                    fontSize = 16.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onScientificFunction("xʸ") }
                )
                CalculatorButton(
                    text = "!",
                    type = ButtonType.FUNCTION,
                    fontSize = 18.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onFactorial() }
                )
                CalculatorButton(
                    text = "(",
                    type = ButtonType.FUNCTION,
                    fontSize = 18.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onParenthesis("(") }
                )
                CalculatorButton(
                    text = ")",
                    type = ButtonType.FUNCTION,
                    fontSize = 18.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onParenthesis(")") }
                )
            }

            // Row 4: AC, ⌫, %, +/-, ÷
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.1f),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                CalculatorButton(
                    text = "AC",
                    type = ButtonType.CLEAR,
                    fontSize = 17.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onClear() }
                )
                CalculatorButton(
                    text = "⌫",
                    type = ButtonType.FUNCTION,
                    icon = Icons.AutoMirrored.Filled.Backspace,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onBackspace() }
                )
                CalculatorButton(
                    text = "%",
                    type = ButtonType.FUNCTION,
                    fontSize = 18.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onPercent() }
                )
                CalculatorButton(
                    text = "+/-",
                    type = ButtonType.FUNCTION,
                    fontSize = 17.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onToggleSign() }
                )
                CalculatorButton(
                    text = "÷",
                    type = ButtonType.OPERATOR,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onOperator("÷") }
                )
            }

            // Row 5: 7, 8, 9, (blank/custom), ×
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.1f),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                CalculatorButton(
                    text = "7",
                    type = ButtonType.NUMBER,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("7") }
                )
                CalculatorButton(
                    text = "8",
                    type = ButtonType.NUMBER,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("8") }
                )
                CalculatorButton(
                    text = "9",
                    type = ButtonType.NUMBER,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("9") }
                )
                CalculatorButton(
                    text = "×",
                    type = ButtonType.OPERATOR,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(2f),
                    onClick = { viewModel.onOperator("×") }
                )
            }

            // Row 6: 4, 5, 6, -, (wide)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.1f),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                CalculatorButton(
                    text = "4",
                    type = ButtonType.NUMBER,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("4") }
                )
                CalculatorButton(
                    text = "5",
                    type = ButtonType.NUMBER,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("5") }
                )
                CalculatorButton(
                    text = "6",
                    type = ButtonType.NUMBER,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("6") }
                )
                CalculatorButton(
                    text = "-",
                    type = ButtonType.OPERATOR,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(2f),
                    onClick = { viewModel.onOperator("-") }
                )
            }

            // Row 7: 1, 2, 3, +
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.1f),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                CalculatorButton(
                    text = "1",
                    type = ButtonType.NUMBER,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("1") }
                )
                CalculatorButton(
                    text = "2",
                    type = ButtonType.NUMBER,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("2") }
                )
                CalculatorButton(
                    text = "3",
                    type = ButtonType.NUMBER,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDigit("3") }
                )
                CalculatorButton(
                    text = "+",
                    type = ButtonType.OPERATOR,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(2f),
                    onClick = { viewModel.onOperator("+") }
                )
            }

            // Row 8: 0, ., =
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.1f),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                CalculatorButton(
                    text = "0",
                    type = ButtonType.NUMBER,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(2f),
                    onClick = { viewModel.onDigit("0") }
                )
                CalculatorButton(
                    text = ".",
                    type = ButtonType.NUMBER,
                    fontSize = 22.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.onDecimal() }
                )
                CalculatorButton(
                    text = "=",
                    type = ButtonType.EQUALS,
                    fontSize = 24.sp,
                    vibrationEnabled = vibrationEnabled,
                    modifier = Modifier.weight(2f),
                    onClick = { viewModel.onEquals() }
                )
            }
        }
    }
}
