package com.example.calculator.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.calculator.engine.AngleUnit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "procalc_settings")

enum class ThemeMode {
    DARK,
    LIGHT,
    SYSTEM
}

data class UserSettings(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val vibrationEnabled: Boolean = true,
    val defaultAngleUnit: AngleUnit = AngleUnit.DEG
)

class SettingsRepository(private val context: Context) {

    private object PreferencesKeys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val VIBRATION_ENABLED = booleanPreferencesKey("vibration_enabled")
        val DEFAULT_ANGLE_UNIT = stringPreferencesKey("default_angle_unit")
    }

    val userSettingsFlow: Flow<UserSettings> = context.dataStore.data.map { preferences ->
        val themeString = preferences[PreferencesKeys.THEME_MODE] ?: ThemeMode.DARK.name
        val themeMode = try {
            ThemeMode.valueOf(themeString)
        } catch (_: Exception) {
            ThemeMode.DARK
        }

        val vibrationEnabled = preferences[PreferencesKeys.VIBRATION_ENABLED] ?: true

        val angleString = preferences[PreferencesKeys.DEFAULT_ANGLE_UNIT] ?: AngleUnit.DEG.name
        val angleUnit = try {
            AngleUnit.valueOf(angleString)
        } catch (_: Exception) {
            AngleUnit.DEG
        }

        UserSettings(
            themeMode = themeMode,
            vibrationEnabled = vibrationEnabled,
            defaultAngleUnit = angleUnit
        )
    }

    suspend fun updateThemeMode(themeMode: ThemeMode) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.THEME_MODE] = themeMode.name
        }
    }

    suspend fun updateVibration(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.VIBRATION_ENABLED] = enabled
        }
    }

    suspend fun updateAngleUnit(unit: AngleUnit) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.DEFAULT_ANGLE_UNIT] = unit.name
        }
    }
}
