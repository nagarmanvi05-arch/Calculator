package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ProCalc Premium Dark Palette
val ProCalcDarkBackground = Color(0xFF0F131A)
val ProCalcDarkSurface = Color(0xFF171D27)
val ProCalcDarkSurfaceVariant = Color(0xFF222B3A)
val ProCalcDarkDisplay = Color(0xFF0A0D12)

val ProCalcNumberKeyDark = Color(0xFF1F2633)
val ProCalcNumberKeyTextDark = Color(0xFFF1F5F9)

val ProCalcOperatorKeyDark = Color(0xFFF59E0B)
val ProCalcOperatorKeyTextDark = Color(0xFFFFFFFF)

val ProCalcFunctionKeyDark = Color(0xFF2C3648)
val ProCalcFunctionKeyTextDark = Color(0xFF93C5FD)

val ProCalcClearKeyDark = Color(0xFFDC2626)
val ProCalcClearKeyTextDark = Color(0xFFFFFFFF)

val ProCalcEqualsKeyDark = Color(0xFF0284C7)
val ProCalcEqualsKeyTextDark = Color(0xFFFFFFFF)

// ProCalc Crisp Light Palette
val ProCalcLightBackground = Color(0xFFF8FAFC)
val ProCalcLightSurface = Color(0xFFFFFFFF)
val ProCalcLightSurfaceVariant = Color(0xFFE2E8F0)
val ProCalcLightDisplay = Color(0xFFF1F5F9)

val ProCalcNumberKeyLight = Color(0xFFFFFFFF)
val ProCalcNumberKeyTextLight = Color(0xFF0F172A)

val ProCalcOperatorKeyLight = Color(0xFFF59E0B)
val ProCalcOperatorKeyTextLight = Color(0xFFFFFFFF)

val ProCalcFunctionKeyLight = Color(0xFFE2E8F0)
val ProCalcFunctionKeyTextLight = Color(0xFF1E293B)

val ProCalcClearKeyLight = Color(0xFFEF4444)
val ProCalcClearKeyTextLight = Color(0xFFFFFFFF)

val ProCalcEqualsKeyLight = Color(0xFF0284C7)
val ProCalcEqualsKeyTextLight = Color(0xFFFFFFFF)
