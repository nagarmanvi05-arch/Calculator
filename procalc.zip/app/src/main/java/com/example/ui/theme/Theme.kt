package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.calculator.data.ThemeMode

private val DarkColorScheme = darkColorScheme(
    primary = ProCalcEqualsKeyDark,
    onPrimary = ProCalcEqualsKeyTextDark,
    secondary = ProCalcOperatorKeyDark,
    onSecondary = ProCalcOperatorKeyTextDark,
    tertiary = ProCalcClearKeyDark,
    onTertiary = ProCalcClearKeyTextDark,
    background = ProCalcDarkBackground,
    onBackground = Color(0xFFF1F5F9),
    surface = ProCalcDarkSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = ProCalcDarkSurfaceVariant,
    onSurfaceVariant = Color(0xFF94A3B8)
)

private val LightColorScheme = lightColorScheme(
    primary = ProCalcEqualsKeyLight,
    onPrimary = ProCalcEqualsKeyTextLight,
    secondary = ProCalcOperatorKeyLight,
    onSecondary = ProCalcOperatorKeyTextLight,
    tertiary = ProCalcClearKeyLight,
    onTertiary = ProCalcClearKeyTextLight,
    background = ProCalcLightBackground,
    onBackground = Color(0xFF0F172A),
    surface = ProCalcLightSurface,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = ProCalcLightSurfaceVariant,
    onSurfaceVariant = Color(0xFF64748B)
)

@Composable
fun ProCalcTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (isDark) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Retain alias for test compatibility if needed
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    ProCalcTheme(
        themeMode = if (darkTheme) ThemeMode.DARK else ThemeMode.LIGHT,
        content = content
    )
}
