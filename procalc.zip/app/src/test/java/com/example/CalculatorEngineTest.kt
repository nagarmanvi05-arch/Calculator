package com.example

import com.example.calculator.engine.AngleUnit
import com.example.calculator.engine.CalculationResult
import com.example.calculator.engine.CalculatorEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CalculatorEngineTest {

    @Test
    fun testBasicArithmetic() {
        val res = CalculatorEngine.evaluate("2+3×4")
        assertTrue(res is CalculationResult.Success)
        assertEquals("14", (res as CalculationResult.Success).formattedResult)
    }

    @Test
    fun testParenthesesAndPrecedence() {
        val res = CalculatorEngine.evaluate("(2+3)×4")
        assertTrue(res is CalculationResult.Success)
        assertEquals("20", (res as CalculationResult.Success).formattedResult)
    }

    @Test
    fun testDecimalPrecision() {
        val res = CalculatorEngine.evaluate("0.1+0.2")
        assertTrue(res is CalculationResult.Success)
        assertEquals("0.3", (res as CalculationResult.Success).formattedResult)
    }

    @Test
    fun testPercentage() {
        val res = CalculatorEngine.evaluate("50%")
        assertTrue(res is CalculationResult.Success)
        assertEquals("0.5", (res as CalculationResult.Success).formattedResult)
    }

    @Test
    fun testPowerAndFactorial() {
        val resPower = CalculatorEngine.evaluate("2^3")
        assertTrue(resPower is CalculationResult.Success)
        assertEquals("8", (resPower as CalculationResult.Success).formattedResult)

        val resFact = CalculatorEngine.evaluate("5!")
        assertTrue(resFact is CalculationResult.Success)
        assertEquals("120", (resFact as CalculationResult.Success).formattedResult)
    }

    @Test
    fun testTrigonometryDegreeMode() {
        val resSin = CalculatorEngine.evaluate("sin(90)", AngleUnit.DEG)
        assertTrue(resSin is CalculationResult.Success)
        assertEquals("1", (resSin as CalculationResult.Success).formattedResult)

        val resCos = CalculatorEngine.evaluate("cos(0)", AngleUnit.DEG)
        assertTrue(resCos is CalculationResult.Success)
        assertEquals("1", (resCos as CalculationResult.Success).formattedResult)

        val resTan = CalculatorEngine.evaluate("tan(45)", AngleUnit.DEG)
        assertTrue(resTan is CalculationResult.Success)
        assertEquals("1", (resTan as CalculationResult.Success).formattedResult)
    }

    @Test
    fun testTrigonometryRadianMode() {
        val resSin = CalculatorEngine.evaluate("sin(π÷2)", AngleUnit.RAD)
        assertTrue(resSin is CalculationResult.Success)
        assertEquals("1", (resSin as CalculationResult.Success).formattedResult)
    }

    @Test
    fun testSquareRootAndLog() {
        val resSqrt = CalculatorEngine.evaluate("sqrt(16)")
        assertTrue(resSqrt is CalculationResult.Success)
        assertEquals("4", (resSqrt as CalculationResult.Success).formattedResult)

        val resLog = CalculatorEngine.evaluate("log(100)")
        assertTrue(resLog is CalculationResult.Success)
        assertEquals("2", (resLog as CalculationResult.Success).formattedResult)
    }

    @Test
    fun testDivisionByZeroHandled() {
        val res = CalculatorEngine.evaluate("10÷0")
        assertTrue(res is CalculationResult.Error)
        assertEquals("Cannot divide by zero", (res as CalculationResult.Error).message)
    }

    @Test
    fun testDomainErrorHandled() {
        val res = CalculatorEngine.evaluate("sqrt(-4)")
        assertTrue(res is CalculationResult.Error)
    }
}
